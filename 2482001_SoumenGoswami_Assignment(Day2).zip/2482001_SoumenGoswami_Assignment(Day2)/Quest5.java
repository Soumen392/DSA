
// 5. Write a method in a separate class to convert an infix expression to its corresponding postfix
// expression.

import generic.Generic_stack;

public class Quest5 {


    //checking whether operator or not
    static boolean isOperator(char c){
        char[] ar={'*','+','-','/','^'};
        for(int i=0;i<ar.length;i++){
            if(c==ar[i])return true;
        }
        return false;
    }


    //infix to postfix conversion--left associativity
    public static char[] infixTopostfix_left_association(String st){
        char[] arr1=st.toCharArray();
        int n=arr1.length;
        Generic_stack.StackG<Character> s=new Generic_stack.StackG<Character>(n);
        int k=0,i=0;
        char[] ans=new char[n];
        while(i<n){
            char curr=arr1[i];
            if(!isOperator(curr) && curr!='(' && curr!=')'){
                ans[k++]=curr;
                i++;
            }
            else if(curr=='('){
                s.push(curr);
                i++;
            }
            else if(curr==')'){
                while(!s.isEmpty() && s.stack_top()!='('){
                    ans[k++]=s.pop();
                }
                s.pop();
                i++;
            }
            else{
                while(!s.isEmpty() && precedence(curr)<=precedence(s.stack_top()) )ans[k++]=s.pop();
                s.push(curr);
                i++;

            }
        }
        while(!s.isEmpty()){
            ans[k++]=s.pop();
        }
        char[] postfix=new char[k+1];
        int m=0;
        for(Character x:ans){
            postfix[m++]=x;
        }
        return postfix;
    }


    //infix to postfix conversion--right associativity
    public static char[] infixTopostfix_right_association(String st){
        char[] arr1=st.toCharArray();
        int n=arr1.length;
        Generic_stack.StackG<Character> s=new Generic_stack.StackG<Character>(n);
        int k=0,i=0;
        char[] ans=new char[n];
        while(i<n){
            char curr=arr1[i];
            if(!isOperator(curr) && curr!='(' && curr!=')'){
                ans[k++]=curr;
                i++;
            }
            else if(curr=='('){
                s.push(curr);
                i++;
            }
            else if(curr==')'){
                while(!s.isEmpty() && s.stack_top()!='('){
                    ans[k++]=s.pop();
                }
                s.pop();
                i++;
            }
            else{
                while(!s.isEmpty() && precedence(curr)<precedence(s.stack_top()) )ans[k++]=s.pop();
                s.push(curr);
                i++;

            }
        }
        while(!s.isEmpty()){
            ans[k++]=s.pop();
        }
        char[] postfix=new char[k+1];
        int m=0;
        for(Character x:ans){
            postfix[m++]=x;
        }
        return postfix;
    }


    //precedence checking
    static int precedence(char c){
        if(c=='^')return 5;
        else if(c=='*' || c=='/')return 3;
        else if(c=='+' || c=='-')return 2;
        else return 0;
    }
    public static void main(String[] args) {

        String st="a^b^c";

        int flag=0;

        for(int i=0;i<st.length();i++){
            if(st.charAt(i)=='^'){
                flag=1;
                break;
            }
        }

        char[] res;

        if(flag==0){
            res=infixTopostfix_left_association(st);
        }else res=infixTopostfix_right_association(st);

        System.out.println("the postfix expression of infix "+st+" is");

        String ans=new String(res);
        System.out.println(ans);
    }
}
