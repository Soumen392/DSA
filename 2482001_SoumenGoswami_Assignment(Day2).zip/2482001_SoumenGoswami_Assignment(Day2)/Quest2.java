
// 2. Write a method in a separate class to check an expression is valid or not.

public class Quest2 {
    public static boolean check(Character a, Character b) {
        if (a == '(' && b == ')') return true;
        else if (a == '{' && b == '}') return true;
        else if (a == '[' && b == ']') return true;
        else return false;
    }

    public static void main(String[] args) {
        String exp1 = "(1*b+c(){r-u()})}";
        Quest1.StackL st = new Quest1.StackL(100);
        int i = 0;

        while (i < exp1.length()) {
            char currentChar = exp1.charAt(i);
            if (currentChar == '(' || currentChar == '{' || currentChar == '[') {
                st.push(currentChar);
            } else if (currentChar == ')' || currentChar == '}' || currentChar == ']') {
                if (st.isEmpty()) {
                    System.out.println("not a valid expression");
                    return;
                }
                Character ch = st.pop();
                if (!check(ch, currentChar)) {
                    System.out.println("not a valid expression");
                    return;
                }
            }
            i++;
        }

        if (st.isEmpty()) {
            System.out.println("valid expression");
        } else {
            System.out.println("not a valid expression");
        }
    }
}
