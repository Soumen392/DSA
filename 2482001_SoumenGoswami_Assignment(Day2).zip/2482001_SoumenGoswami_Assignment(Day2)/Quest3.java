// 4. Write a method in a separate class to evaluate a postfix expression. (Consider more than single
// digit number as a input)
import generic.Generic_stack;

import java.util.*;

public class Quest3 {
    public static int performOperation(int a,int b,String op){
        switch(op){
            case "*":
                return b*a;
            case "/":
                return b/a;
            case "+":
                return b+a;
            case "-":
                return b-a;
            default:
                System.out.println("invalid operator");
                throw new IllegalArgumentException("invalid operator "+op);

        }
    }
    //evaluating value of postfix expression
    public static  int Evalute_postfix(String postfix){
        StringTokenizer s=new StringTokenizer(postfix);
        int n=postfix.length();
        Generic_stack.StackG<Integer> st=new Generic_stack.StackG<Integer>(n);
        while(s.hasMoreTokens()){
            String el=s.nextToken();
            if(isOperator(el)){
                if(!st.isEmpty()){
                    try{
                        int a=st.pop();
                        int b=st.pop();
                        int res=performOperation(a,b,el);
                        st.push(res);
                    }catch(Exception e){
                        System.out.println("stack has elements < 2");
                    }
                }
            }else{
                st.push(Integer.parseInt(el));
            }
        }
        return st.stack_top();
    }
    //checking whether operator or not
    public static boolean isOperator(String s){
        return s.equals("*") || s.equals("/") || s.equals("+")  || s.equals("-");
    }
    public static void main(String[] args) {
        String postfix="19 3 4 * 8 + 4 / - ";     //postfix expression
        int ans=Evalute_postfix(postfix);
        System.out.println("final answer is "+ans);   //final output
    }
}
