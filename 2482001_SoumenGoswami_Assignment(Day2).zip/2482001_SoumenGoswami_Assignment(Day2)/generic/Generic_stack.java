package generic;// package stack_generic;


public class Generic_stack {
    public static class StackG<T>{
        T[] arr;
        int n;
        static int i=-1;
        @SuppressWarnings("unchecked")
        public StackG(int n){
            this.n=n;
            arr=(T[])new Object[n];
        }
        public boolean isFull(){
            if(i==n-1){
                System.out.println("stack is full");
                return true;
            }
            else{
                return false;
            }
        }
        public boolean isEmpty(){
            return (i==-1)?true:false;
        }
        public void push(T el){
            if(this.isFull()){
                System.out.println(el+" cannot be pushed in stack");
            }else{
                arr[++i]=el;
            }
        }
        public T pop(){
            return !isEmpty()?arr[i--]:null;
        }
        public T stack_top(){
            return isEmpty()?null:arr[i];
        }

    }

    public static void main(String[] args) {
        StackG<Integer> st=new StackG<Integer>(3);
        st.push(11);
        st.push(12);
        st.push(55);
        st.push(111);
    }
}
