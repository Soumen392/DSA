// 6. Write a method in a separate class to convert an infix expression to its corresponding prefix
// expression.


import generic.Generic_stack;

public class Quest6 {

    //checking whether operator or not
    static boolean isOperator(char c){
        char[] ar={'*','+','-','/'};
        for(int i=0;i<ar.length;i++){
            if(c==ar[i])return true;
        }
        return false;
    }

    //infix to postfix conversion--left associativity
    public static char[] infixTopostfixleftassociation(String st){
        char[] arr1=st.toCharArray();
        int n=arr1.length;
        Generic_stack.StackG<Character> s=new Generic_stack.StackG<Character>(n);
        int k=0,i=0;
        char[] ans=new char[n];
        while(i<n){
            char curr=arr1[i];
            if(!isOperator(curr) && curr!='(' && curr!=')'){
                ans[k++]=curr;
                i++;
            }
            else if(curr=='('){
                s.push(curr);
                i++;
            }
            else if(curr==')'){
                while(!s.isEmpty() && s.stack_top()!='('){
                    ans[k++]=s.pop();
                }
                s.pop();
                i++;
            }
            else{
                while(!s.isEmpty() && precedence(curr)<=precedence(s.stack_top()) )ans[k++]=s.pop();
                s.push(curr);
                i++;

            }
        }
        while(!s.isEmpty()){
            ans[k++]=s.pop();
        }
        char[] postfix = new char[k];
        System.arraycopy(ans, 0, postfix, 0, k);
        return postfix;
    }



    //precedence checking
    static int precedence(char c){
        // if(c=='^')return 5;
        if(c=='*' || c=='/')return 3;
        else if(c=='+' || c=='-')return 2;
        else return 0;
    }

    public static String reverse_string(String st){
        StringBuilder ans=new StringBuilder();

        for (int i = 0; i < st.length(); i++) {
            char curr = st.charAt(i);
            if (curr == '(') {
                ans.append(')');
            } else if (curr == ')') {
                ans.append('(');
            } else {
                ans.append(curr);
            }
        }

        return ans.reverse().toString();
    }

    public static void main(String[] args) {
        String st="(A-B/C)*(A/K-L)";
        String rev_st=reverse_string(st);


        char[] res;
        res=infixTopostfixleftassociation(rev_st);


        System.out.println("infix to prefix expression of "+st+"is ");
        System.out.println(reverse_string(new String(res)));
    }
}

