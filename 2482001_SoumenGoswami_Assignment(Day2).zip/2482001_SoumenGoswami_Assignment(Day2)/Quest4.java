
import generic.Generic_stack;

import java.util.*;
// 4. Write a method in a separate class to evaluate a prefix expression. (Consider more than single
// digit number as a input)

public class Quest4 {
    public static int performOperation(int a,int b,String op){
        switch(op){
            case "*":
                return a*b;
            case "/":
                return a/b;
            case "+":
                return a+b;
            case "-":
                return a-b;
            default:
                System.out.println("invalid operator");
                throw new IllegalArgumentException("invalid operator "+op);

        }
    }
    //evaluating value of prefix expression
    public static  int Evalute_prefix(String postfix){
        StringTokenizer s=new StringTokenizer(postfix);
        int n=postfix.length();
        Generic_stack.StackG<Integer> st=new Generic_stack.StackG<Integer>(n);
        Generic_stack.StackG<String> tok=new Generic_stack.StackG<String>(n);

        //to get reverse(tokens) of stringtokenizer
        while(s.hasMoreTokens()){
            String token=s.nextToken();
            tok.push(token);
        }
        int k=0,i=0;
        String[] arr=new String[n];    //for storing tokens of stringtokenizer
        while(!tok.isEmpty()){
            arr[k++]=tok.pop();
        }
        //traversing the string array
        while(i<k){
            String el=arr[i];
            if(isOperator(el)){
                if(!st.isEmpty()){
                    try{
                        int a=st.pop();
                        int b=st.pop();
                        int res=performOperation(a,b,el);
                        st.push(res);
                    }catch(Exception e){
                        System.out.println("stack has elements < 2");
                    }
                }
            }else{
                st.push(Integer.parseInt(el));
            }
            i++;
        }
        return st.stack_top();     //result
    }
    //checking whether operator or not
    public static boolean isOperator(String s){
        return s.equals("*") || s.equals("/") || s.equals("+")  || s.equals("-");
    }
    public static void main(String[] args) {
        String postfix= "- + 5 6 * 17 12";     //prefix expression
        int ans=Evalute_prefix(postfix);
        System.out.println("final answer is "+ans);   //final output
    }
}
