// package stack_class;
import java.util.*;
// 1. Write a program to implement a Stack class (use an Array to store the elements of the stack).
// [Implement Stack Overflow and Underflow by user-defined Exception]. Write a method to
// check if two stacks are carrying similar elements or not.(Repetition of the elements are not
// considered)

// Overflow exception
class overflow_exception extends Exception {
    public String toString() {
        return "stack overflowed";
    }
}

// Underflow exception
class under_flow_exception extends Exception {
    public String toString() {
        return "stack underflowed";
    }
}

public class Quest1 {
    // Stack class design
    protected static class StackL {
        Character arr[];
        int n;
        int i;

        StackL(int n) {
            arr = new Character[n];
            this.i = 0;
            this.n = n;
        }

        // Push operation
        void push(Character el) {
            try {
                if (i >= n)
                    throw new overflow_exception();
            } catch (Exception e) {
                System.out.println(e);
                return;
            }
            arr[i++] = el;
        }
        public boolean isEmpty(){
            return i==0;
        }
        public boolean isFull(){
            return i==n-1;
        }

        // Pop operation
        public Character pop() {
            try {
                if (i == 0)
                    throw new under_flow_exception();
            } catch (Exception e) {
                System.out.println(e);
                return null;
            }
            return arr[--i];  // Decrement `i` and return the correct element
        }

        // Check if two stacks have the same unique elements
        void check(StackL st1, StackL st2) {
            // Using HashSet to compare unique elements without order
            Set<Character> set1 = new HashSet<>();
            Set<Character> set2 = new HashSet<>();

            // Add elements to the sets
            for (int i = 0; i < st1.i; i++) {
                set1.add(st1.arr[i]);
            }
            for (int i = 0; i < st2.i; i++) {
                set2.add(st2.arr[i]);
            }

            // Compare sets
            if (set1.equals(set2)) {
                System.out.println("Both stacks have the same unique elements");
            } else {
                System.out.println("Stacks do not have the same unique elements");
            }
        }
    }

    public static void main(String[] args) {
        StackL st1 = new StackL(5);
        StackL st3 = new StackL(5);
        StackL st2 = new StackL(5);

        // Push some elements to the stacks
        st1.push('L');
        st1.push('2');
        st1.push('R');

        st2.push('B');
        st2.push('2');
        st2.push('c');

        // Check if the stacks have the same unique elements
        st3.check(st1, st2);
    }
}
