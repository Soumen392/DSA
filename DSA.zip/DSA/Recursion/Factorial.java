package Recursion;

public class Factorial {
    public static void main(String[] args) {
        int ans = findFact(5);
        System.out.println(ans);
    }

    static int findFact(int n){
        if(n == 0){
            return 1;
        }

        return n * findFact(n - 1);
    }
}
