package Recursion;

import java.util.ArrayList;

public class Subset {
    public static void main(String[] args) {
        System.out.println(foundSet2("abc",""));

    }

    static void foundSet(String up, String p){
        if(up.isEmpty()){
            System.out.print(p+" ");
            return;
        }

        char ch = up.charAt(0);
        foundSet(up.substring(1),p + ch);
        foundSet(up.substring(1) , p );
    }
    static ArrayList<String> foundSet2(String up, String p){
        if(up.isEmpty()){
            ArrayList<String> list = new ArrayList<>();
            list.add(p);
            return list;
        }

        char ch = up.charAt(0);
        ArrayList<String> left = foundSet2(up.substring(1),p + ch);
        ArrayList<String> right = foundSet2(up.substring(1),p );

        left.addAll(right);
        return left;
    }
}
