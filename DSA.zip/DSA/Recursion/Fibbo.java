package Recursion;

public class Fibbo {
    public static void main(String[] args) {
//        for (int i = 0; i < 50; i++) {
//            System.out.println(fibbo(i));
//        }

        System.out.println(fibbo2(3));

    }

    public static int fibbo(int n){
        return (int) ((1/Math.sqrt(5)) * ( Math.pow(((1 + Math.sqrt(5))/2),n) - Math.pow(((1 - Math.sqrt(5))/2),n)));
    }
    // Time complexity is ((1+sqrt(5))/2)

    public static int fibbo2(int n){
        if(n <= 1){
            return n;
        }
        return fibbo2(n - 1) + fibbo2(n - 2);
    }
}
