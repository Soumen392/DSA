package Recursion;

public class SumDigits {
    public static void main(String[] args) {
        int ans = getSumDig(1342);
        System.out.println(ans);
    }

    static int getSumDig(int n){

        if( n == 0){
            return 0;
        }


        return getSumDig(n / 10) + (n % 10) ;


    }
}
