package Recursion;

public class IsSortedArray {
    public static void main(String[] args) {
        int[] arr  = {1,4,5,8,1};
        boolean ans = IsSorted(arr, 0);
        System.out.println(ans);
    }
    static boolean IsSorted(int [] arr, int s){
        if( s == arr.length - 1 ){
            return true;
        }



        return arr[s] < arr[s + 1] && IsSorted(arr, s + 1) ;

    }
}
