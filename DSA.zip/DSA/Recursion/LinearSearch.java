package Recursion;

import java.util.ArrayList;

public class LinearSearch {
    public static void main(String[] args) {
        int[] arr  = {1,4,5,8,5};
        findAll(arr, 5,0);
        System.out.println(list);
    }

    static boolean linear(int[] arr, int target, int i){
        if(i == arr.length - 1){
            return  false;
        }

        return arr[i] == target || linear(arr, target , i + 1);
    }

    static int linear1(int[] arr, int target, int i){
        if(i == arr.length - 1){
            return  -1;
        }
        if (arr[i] == target){
            return i;
        }

        return linear1(arr, target , i + 1);
    }

    static ArrayList<Integer> list = new ArrayList<>();

    static void findAll(int[] arr, int target, int i){
        if(i == arr.length - 1){
            if(target == arr[i]){
                list.add(i);
            }
            return ;
        }
        if (arr[i] == target){
           list.add(i);
        }

        findAll(arr, target , i + 1);
    }
}
