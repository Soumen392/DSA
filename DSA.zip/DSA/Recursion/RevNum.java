package Recursion;

public class RevNum {
    public static void main(String[] args) {
//        revNum3(1234);
        System.out.println(revNum3(1234));
    }

    static void revNum1(int n){

        if(n / 10 == 0){
            System.out.print(n);
            return;
        }

        System.out.print(n % 10 +"");
        revNum1(n / 10);
    }

    static int sum = 0;

    static void revNum2(int n){
        if(n == 0){
            return;
        }
        int rem = n % 10;

        sum = sum * 10 + rem;

        revNum2(n / 10);
    }

    static int revNum3(int n ){
        //sometimes you might need some additional variables in the argument
        //in that case, makes another functions

        int digit = (int) (Math.log10(n)) + 1;

        return helper(n, digit);
    }

    private static int helper(int n, int digit) {
        if(n % 10 == n){
            return n;
        }

        int rem = n % 10;

        return rem * (int) (Math.pow(10,digit - 1)) + helper(n / 10, digit - 1);
    }
}
