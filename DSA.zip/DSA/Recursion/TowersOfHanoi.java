package Recursion;

public class TowersOfHanoi{
    public static void hanoi(int n, char source, char auxiliary, char destination) {
        // Pre-condition: n >= 1, disks are stacked correctly on source rod
        if (n == 1) {
            System.out.println("Move disk 1 from " + source + " to " + destination);
            return;
        }
        hanoi(n - 1, source, destination, auxiliary); // Move n-1 disks to auxiliary
        System.out.println("Move disk " + n + " from " + source + " to " + destination);
        hanoi(n - 1, auxiliary, source, destination); // Move n-1 disks to destination
    }

    public static void main(String[] args) {
        int n = 3; // Number of disks
        hanoi(n, 'A', 'B', 'C'); // A=source, B=auxiliary, C=destination
    }
}