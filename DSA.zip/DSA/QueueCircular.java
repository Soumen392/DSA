import java.util.Queue;

public class QueueCircular {
    private int[] queue;
    private int rear,front,size;

    public QueueCircular(int size) {
        queue = new int[size];
        front = rear = -1;
        this.size = size;
    }

    private boolean isFull(){
        return (rear + 1)%size == front;
    }
    private boolean isEmpty(){
        return front == -1;
    }

    public void enqueue(int item){
        if(isFull()){
            System.out.println("Queue is full");
            return;
        }
        if(isEmpty()){
            front = 0;
        }
        rear = (rear + 1) % size;
        queue[rear] = item;
    }

    public int dequeue(){
        if(isEmpty()){
            System.out.println("Queue is empty");
            return -1;
        }
        int item = queue[front];
        if(front == rear){
            rear = front = -1;
        }
        else{
            front = (front + 1)%size;
        }
        return item;

    }
}

class Main2{
    public static void main(String[] args) {
        QueueCircular qc = new QueueCircular(5);
        qc.enqueue(1);
        qc.enqueue(2);
        qc.enqueue(3);
        qc.enqueue(4);
        qc.enqueue(5);
        for (int i = 0; i < 5; i++) {
            System.out.print(qc.dequeue()+" ");
        }
    }
}
