public class DLL {
    private Node head;
//    private Node tail;
    int size;

    public DLL() {
        this.size = 0;
    }
    //insert part
    public void insertFirst(int val){
        Node node = new Node(val);
        node.next = head;
        node.prev = null;
        if(head != null){
            head.prev = node;
        }
        head = node;
        size++;
    }

    public void insertLast(int val){
        Node node = new Node(val);
        node.next = null;
        if(head == null){
            node.prev = null;
            head = node;
            return;
        }
        Node last = head;
        while(last.next != null){
            last = last.next;
        }
        last.next = node;
        node.prev = last;
        size++;

    }

    public void insertValue(int value,int index){
        Node node =  new Node(value);
        if(index == 0){
            insertFirst(value);
        }
        if(index == size){
            insertLast(value);
        }
        Node temp = head;
        for (int i = 1; i < index ; i++) {
            temp = temp.next;
        }
        Node nextTemp = temp.next;
        temp.next = node;
        node.prev = temp;
        node.next = nextTemp;
        nextTemp.prev = node;

    }


    //Display area
    public void display(){
        Node temp = head;
        System.out.print("Null<->");
        while(temp != null){
            System.out.print(temp.value+"<->");
//            Node last = temp;
            temp = temp.next;
        }
        System.out.println("End");

    }

    public void displauRev(){
        Node temp = head;
        Node last = null;
        System.out.print("Null<->");
        while(temp != null){
            last = temp;
            temp = temp.next;
        }
        while(last != null){
            System.out.print(last.value+"<->");
            last = last.prev;
        }
        System.out.print("Start");
    }

    private class Node{
        private int value;
        private Node next;
        private Node prev;

        public Node(int value) {
            this.value = value;
        }

        public Node(int value, Node next, Node prev) {
            this.value = value;
            this.next = next;
            this.prev = prev;
        }
    }
}
