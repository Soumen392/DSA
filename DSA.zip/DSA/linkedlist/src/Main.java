public class Main {
    public static void main(String[] args) {

//        LL list = new LL();
//        list.insertFirst(3);
//        list.insertFirst(10);
//        list.insertFirst(20);
//        list.insertFirst(25);
//        list.insertFirst(30);
//        list.insertValue(99,5);
//        list.insertLast(100);
//
//        System.out.println(list.deleteLast());
//        System.out.println(list.deleteFirst());
//        System.out.println(list.deleteItem(2));
//
//        System.out.println(list.find(3));
//        list.displayValue();

//        DLL dlist = new DLL();
//        dlist.insertFirst(2);
//        dlist.insertFirst(22);
//        dlist.insertFirst(14);
//        dlist.insertFirst(10);
//        dlist.insertLast(12);
//        dlist.insertValue(15,3);
//        dlist.display();
//        dlist.displauRev();

        CLL clist = new CLL();
        clist.insertFirst(10);
        clist.insertFirst(11);
        clist.insertFirst(12);
        clist.insertFirst(13);
        clist.insertLast(14);
        clist.insertValue(3,9);
        clist.dislpay();


    }
}