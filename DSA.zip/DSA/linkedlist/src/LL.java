public class LL {
    private Node tail;
    private Node head;
    private int size;

    public LL() {
        this.size = 0;
    }
    //Insert area
    public void insertFirst(int val){
        Node node = new Node(val);
        node.next = head;
        head = node;
        if(tail == null){
            tail = head;
        }
        size ++;
    }

    public void insertLast(int val){
        Node node = new Node(val);
        if(tail == null){
            insertFirst(val);
        }
        tail.next = node;
        tail = node;
        size++;
    }

    public void insertValue(int val, int index){
        if(index == 0){
            insertFirst(val);
            return;
        }
        if(index == size){
            insertLast(val);
            return;
        }

        Node temp = head;
        for(int i = 1; i < index; i++){
            temp = temp.next;
        }
        Node node = new Node(temp.next,val);
        temp.next = node;
        size++;
    }

    //delete area

    public int deleteFirst(){
        int value = head.value;
        head = head.next;
        if(head == null){
            tail = null;
        }
        size--;
        return value;

    }

    public int deleteLast(){
        if(size <= 1){
            return deleteFirst();
        }
        Node secondLast = getIndex(size - 2);
        int value = tail.value;
        tail = secondLast;
        tail.next = null;
        size--;
        return value;
    }

    public int deleteItem(int index){
        if(index == 0){
            return deleteFirst();
        }
        if(index == size - 1){
            return deleteLast();
        }
        Node prev = getIndex(index - 1);
        int value =  prev.next.value;
        prev.next = prev.next.next;
        size--;
        return value;
    }

    public Node getIndex(int index){
        Node node = head;
        for (int i = 0; i < index; i++) {
            node = node.next;
        }
        return node;
    }

    //Find element
    public int find(int value){
        Node node = head;
        int index = 0;
        while(node != null){
            if(node.value == value){
                return index;
            }
            node = node.next;
            index++;
        }
        return -1;
    }

    //display area
    public void displayValue(){
        Node temp = head;
        while(temp != null){
            System.out.print(temp.value+"->");
            temp = temp.next;
        }
        System.out.println("End");
    }

    private class Node{
        private int value;
        private Node next;

        public Node(int value) {
            this.value = value;
        }

        public Node(Node next, int value) {
            this.next = next;
            this.value = value;
        }
    }
}
