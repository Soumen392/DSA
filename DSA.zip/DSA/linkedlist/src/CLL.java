
public class CLL {
    private Node head;
    private Node tail;

    public  CLL(){
        this.head = null;
        this.tail = null;
    }

    public void insertFirst(int value){
        Node node = new Node(value);
        if(head == null){
            head = node;
            tail = head;
            return;
        }
        node.next = head;
        tail.next = node;
        head = node;

    }
    public void insertLast(int value){
        Node node = new Node(value);
        if(tail == null){
            insertFirst(value);
        }
        tail.next = node;
        node.next = head;
        tail = node;
    }
    public void insertValue(int index, int value){
        Node node = new Node(value);
        Node temp = head;
        for (int i = 0; i < index; i++) {
            temp = temp.next;
        }
        node.next = temp.next.next;
        temp.next = node;
    }

    public void dislpay(){
        Node temp = head;
        while(temp != tail){
            System.out.print(temp.value + "->");
            temp = temp.next;
        }
        System.out.println(tail.value + "->" + head.value);
    }

    private class Node{
        int value;
        Node next;

        public Node(int value) {
            this.value = value;
        }

        public Node(int value, Node next) {
            this.value = value;
            this.next = next;
        }
    }
}
