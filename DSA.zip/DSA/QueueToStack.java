import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class QueueToStack {
    public static void transfer(Queue<Integer> Q, Stack<Integer> S) {
        // Step 1: Reverse Q into S
        while (!Q.isEmpty()) {
            S.push(Q.poll());
        }

        // Step 2: Restore Q's original order
        while (!S.isEmpty()) {
            Q.add(S.pop());
        }

        // Step 3: Transfer to S with correct order
        while (!Q.isEmpty()) {
            S.push(Q.poll());
        }
    }

    public static void main(String[] args) {
        Queue<Integer> Q = new LinkedList<>();
        Stack<Integer> S = new Stack<>();

        // Initialize queue: [1, 2, 3] (front=1, back=3)
        for (int i = 1; i <= 3; i++) {
            Q.add(i);
        }

        System.out.println("Original Queue: " + Q); // [1, 2, 3]
        transfer(Q, S);
        System.out.println("Final Stack : " + S); // [1, 2, 3]
    }
}