package Sorting;

import java.util.Arrays;

public class QuickSort {
    public static void main(String[] args) {
        int[] arr = {5,4,3,2,1};
        Sort(arr,0, arr.length - 1);
        System.out.println(Arrays.toString(arr));
    }
    static void Sort(int[] arr, int low, int high){
        int start = low;
        int end = high;
        int mid = start + ( end - start)/2;
        int pivot = arr[mid];

        if(low >= high){
            return;
        }

        while(start <= end ){
            if(arr[start] < pivot ){
                start ++;
            }
            if(arr[end] > pivot){
                end--;
            }
            if(start <= end){
                int temp = arr[start];
                arr[start] = arr[end];
                arr[end] = temp;
                start++;
                end--;
            }
        }
        //now my pivot is placed in correct position now sort remaining two halves
        Sort(arr,low,end);
        Sort(arr,start,high);

    }
}
