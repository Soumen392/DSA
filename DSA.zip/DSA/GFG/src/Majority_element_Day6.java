import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class Majority_element_Day6 {
    public static void main(String[] args) {
        int [] arr = {1,1,1,3,3,2,2,2};
        int e1 = 0;
        int e2 = 0;
        int c1 = 0;
        int c2 = 0;
        for(int num : arr){
            if(num == e1){
                c1++;
            } else if (num == e2) {
                c2++;
            } else if (c1 == 0) {
                e1 = num;
                c1 = 1;
            } else if (c2 == 0) {
                e2 = num;
                c2 = 1;
            }else{
                c1--;
                c2--;
            }
        }
        List<Integer> ans = new ArrayList<>();
        int count1 = 0;
        int count2 = 0;
        int len = arr.length;
        for (int i = 0; i < len; i++) {
            if(arr[i] == e1){
                count1++;
            } else if (arr[i] == e2) {
                count2++;
            }
        }
        if(count1 > len/3){
            ans.add(e1);
        } if(count2 > len/3){
            ans.add(e2);
        }
        Collections.sort(ans);
        System.out.println(ans);

    }
}
