package Searching;

public class SearchRotatedSorted_GFG_DAY30 {
    public static void main(String[] args) {
        int[] arr = {5, 6, 7, 8, 9, 10, 1, 2, 3};
        int key = 3;
        System.out.println(index(arr, key));
    }

    static int index(int[] arr, int key){
        int start = 0;
        int end = arr.length - 1;
        int ans = -1;
        while(start < end){
            int mid = start + ( end - start )/2;
            if(arr[mid] == key){
                ans = mid;
                break;
            }
            else if(key < arr[mid]){
                start = mid + 1;
            }
            else{
                end = mid;
            }
        }

        return ans;
    }
}
