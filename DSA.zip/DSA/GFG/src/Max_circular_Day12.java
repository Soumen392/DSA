public class Max_circular_Day12 {
    public static void main(String[] args) {
        int[] arr = {8, -8, 9, -9, 10, -11, 12};
        System.out.println(maxCircular(arr));
    }
    static int maxCircular(int [] arr){
        int n = arr.length;
        if(n == 0){
            return 0;
        }
        int x = kudans(arr);
        int y = 0;
        for (int i = 0; i < n; i++) {
            y += arr[i];
            arr[i] *= -1;
        }
        int z = kudans(arr);
        if(y + z == 0){
            return x;
        }
        return Math.max(x, (y+z));
    }
    static int kudans(int[] arr){
        int currSum = 0;
        int maxSum = Integer.MIN_VALUE;
        for (int j : arr) {
            currSum += j;
            maxSum = Math.max(maxSum, currSum);
            if (currSum < 0) {
                currSum = 0;
            }
        }
        return maxSum;
    }
}
