package string;

public class Min_Char_Palindrome_Day19 {
    public static void main(String[] args) {
        String s = "abc";
        String rev = new StringBuilder(s).reverse().toString();
        String newStr = s + "$" + rev;
        int n = newStr.length();
        int[] lps = lpsCalculate(newStr,n);
        int m = s.length();
        int ans = m - lps[n - 1];
        System.out.println(ans);

    }
    static int[] lpsCalculate(String s,int n){
        int [] lps = new int[n];
        int i = 1;
        lps[0] = 0;
        int j = 0;
        while(i < n){
            if (s.charAt(i) == s.charAt(j)){
                lps[i] = j + 1;
                i++;
                j++;

            }
            else{
                if(j != 0){
                    j = lps[j - 1];
                }
                else{
                    lps[i] = 0;
                    i++;
                }
            }
        }
        return lps;
    }
}
