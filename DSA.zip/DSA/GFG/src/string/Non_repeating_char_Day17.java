package string;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class Non_repeating_char_Day17 {
    public static void main(String[] args) {
        String s = "GeeksforGeeks";
        repeatChar(s);
    }
    static void repeatChar(String s){
        String s2 = s.toLowerCase();
        int[] repeat = new int[26];


        for(char ch : s2.toCharArray()){
            repeat[ch - 'a'] ++;
        }
        System.out.println(Arrays.toString(repeat));

        for(char ch : s2.toCharArray()){
            if(repeat[ch - 'a'] == 1){
                System.out.println(ch);
                break;
            }

        }
        System.out.println(Arrays.toString(repeat));
    }
}
