package string;

public class Sum_binarynums_Day15 {
    public static void main(String[] args) {
        String s1 = "1101";
        String s2 = "111";
        System.out.println(addBinary(s1,s2));

    }
    static String addBinary(String s1, String s2){
        int i = s1.length() - 1;
        int j = s2.length() - 1;
        int carry = 0;
        String result = "";

        while (i >= 0 || j >= 0 || carry > 0) {
            int bit1 = (i >= 0) ? s1.charAt(i) - '0' : 0;
            int bit2 = (j >= 0) ? s2.charAt(j) - '0' : 0;

            int sum = bit1 + bit2 + carry;
            result = (sum % 2) + result;
            carry = sum / 2;

            i--;
            j--;
        }

        // Remove leading zeros
        int k = 0;
        while (k < result.length() - 1 && result.charAt(k) == '0') {
            k++;
        }

        return result.substring(k);
    }
}
