package string;

import java.io.PrintWriter;
import java.util.ArrayList;

public class Kmp_algo_Day18 {
    public static void main(String[] args) {
        String txt = "geeksforgeeks";
        String pat = "geek";
        ArrayList<Integer> ans = new ArrayList<>();
        int n = txt.length();
        int m = pat.length();
        int [] lps = new int[m];
        computeLps(lps,pat,m);
        int i = 0;
        int j = 0;

        while(i < n){
            if(txt.charAt(i) == pat.charAt(j)){
                i++;
                j++;
            }
            else{
                if(j != 0){
                    j = lps[j - 1];
                }
                else{
                    i++;
                }
            }
            if(j == m){
                ans.add(i - j);
                j = lps[j - 1];
            }
        }
        System.out.println(ans);

    }
    static void computeLps(int[] lps, String pat,int m){
        int j = 0;
        int i = 1;
        while(i < m){
            if(pat.charAt(i) == pat.charAt(j)){
                lps[i] = j + 1;
                j++;
                i++;
            }
            else{
                if (j!=0){
                    j = lps[j - 1];
                }
                else{
                    lps[i] = 0;
                    i++;
                }
            }

        }
    }
}
