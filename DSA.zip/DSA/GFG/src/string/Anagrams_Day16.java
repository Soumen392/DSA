package string;

import java.util.Arrays;

public class Anagrams_Day16 {
    public static void main(String[] args) {
        String s1 = "aab";
        String s2 = "abb";
        System.out.println(anagramCheck(s1,s2));

    }

    static boolean anagramCheck(String s1, String s2) {
        if(s1.length() != s2.length()){
            return false;
        }
        else{
            int[] count = new int[26];

            // Count characters in s1
            for (int i = 0; i < s1.length(); i++) {
                count[s1.charAt(i) - 'a']++;
            }

            // Subtract counts using s2
            for (int i = 0; i < s2.length(); i++) {
                count[s2.charAt(i) - 'a']--;
            }

            // Check all counts are 0
            for (int i = 0; i < 26; i++) {
                if (count[i] != 0) return false;
            }

            return true;
        }

    }
}
