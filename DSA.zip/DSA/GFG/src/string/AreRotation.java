package string;

public class AreRotation {
    public static void main(String[] args) {
        String s1 = "abcd";
        String s2 = "cdab";
        System.out.println(rotation(s1, s2));
    }
    static boolean rotation(String s1, String s2){
        if(s1.length() != s2.length()){
            return false;
        }

        String concat = s1 + s1;

        return concat.lastIndexOf(s2) >= 0;
    }
}
