import java.util.Arrays;

public class Zero {
    public static void main(String[] args) {
        int[] arr = {1, 2, 0, 4, 3, 0, 5, 0};
        pushZerosToEnd(arr);
        System.out.println(Arrays.toString(arr));
    }

    static void pushZerosToEnd(int[] arr) {
        for (int i = 0; i < arr.length - 1 ; i++) {
            boolean Is_swapped = false;
            for (int j = 1; j < arr.length - i ; j++) {
                if(arr[j-1] == 0){
                    int temp = arr [j];
                    arr[j] = arr[j-1];
                    arr[j-1] = temp;
                    Is_swapped = true;
                }
            }
            if (!Is_swapped){
                break;
            }

        }
    }

    static int [] pushZero(int[] arr){
        int index = 0;
        for(int i =0;i < arr.length; i++){
            if(arr[i] != 0){
                arr[index] = arr[i];
                index++;
            }
        }

        while(index< arr.length){
            arr[index] = 0;
            index++;
        }

        return arr;
    }
}
