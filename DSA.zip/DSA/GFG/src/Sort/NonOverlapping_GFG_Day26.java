import java.util.Arrays;

public class NonOverlapping_GFG_Day26 {
    public static void main(String[] args) {
        int [][] arr = {{1,2},{2,3},{3,4},{1,3}};
        System.out.println(nonOverlappingIntervals(arr));
    }
    public static int nonOverlappingIntervals(int[][] intervals){
        Arrays.sort(intervals,(a, b) -> a[1] - b[1]);
        int n = intervals.length;
        int count = 0;
        int end = intervals[0][1];
        for(int i = 1 ; i < n ; i++){
            if(intervals[i][0] < end){
                count = count + 1;
            }
            else{
                end = intervals[i][1];
            }
        }

        return count;
    }
}
