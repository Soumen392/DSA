import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Overlapping_Intervals {
    public static void main(String[] args) {
        int [][] arr = {{1,3},{2,4},{7,8},{6,9}};
        Arrays.sort(arr, (int[]a,int[]b) -> a[0] - b[0]);

        List<int[]> res = new ArrayList<>();

        for(int[] intervals : arr){
            if(res.isEmpty() || res.getLast()[1] < intervals[0]){
                res.add(intervals);
            }
            else{
                res.getLast()[1] = Math.max(res.getLast()[1], intervals[1]);
            }
        }

        System.out.println(Arrays.deepToString(res.toArray()));
    }

}
