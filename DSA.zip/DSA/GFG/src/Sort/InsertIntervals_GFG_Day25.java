import java.util.ArrayList;
import java.util.Arrays;

public class InsertIntervals_GFG_Day25 {
    public static void main(String[] args) {
        int[][] arr = {{1,3}, {4,5}, {6,7}, {8,10}};
        int[] arr1 = {5,6};
        System.out.println(Arrays.deepToString(insertIntervals(arr,arr1).toArray()));
    }
    public static ArrayList<int[]> insertIntervals(int[][] intervals, int[] newInterval){
        ArrayList<int[]> res = new ArrayList<>();
        int n = intervals.length;
        int i = 0;
        while (i < n && intervals[i][1] < newInterval[0]){
            res.add(intervals[i]);
            i++;
        }
        while(i < n && intervals[i][0] <= newInterval[1]){
            newInterval[0] = Math.min(intervals[i][0], newInterval[0]);
            newInterval[1] = Math.max(intervals[i][1], newInterval[1]);
            i++;

        }

        res.add(newInterval);

        while(i < n){
            res.add(intervals[i]);
            i++;
        }

        return res;
    }
}
