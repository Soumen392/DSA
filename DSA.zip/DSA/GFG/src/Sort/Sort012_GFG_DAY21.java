import java.util.Arrays;

public class Sort012_GFG_DAY21 {
    public static void main(String[] args) {
        int[] arr = {0,0,1,2,0,0,1,1,2,0,1};
        int i = 0;
        int j = 0;
        int k = arr.length - 1;

        while(j <= k){
            if(arr[j] == 0){
                swap(arr, i, j);
                i++;
                j++;
            }
            else if(arr[j] == 1){
                j++;
            }
            else{
                swap(arr, k, j);
                k--;
            }
        }

        System.out.println(Arrays.toString(arr));

    }


    static void swap(int[] arr, int a, int b){
        int temp = arr[a];
        arr[a] = arr[b];
        arr[b] = temp;
    }
}
