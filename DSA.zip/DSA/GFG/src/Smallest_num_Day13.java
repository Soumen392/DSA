import java.util.Arrays;

public class Smallest_num_Day13 {
    public static void main(String[] args) {
        int[] arr = {2, -3, 4, 1, 1, 7};
        Arrays.sort(arr);
        int n = arr.length;
        int num = 1;
        for(int i = 0; i < n; i++ ) {
            if(arr[i] == num && arr[i] >= 1){
                num ++;
            }
        }
        System.out.println(num);
    }
}
