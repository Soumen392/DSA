public class Buy_Sell_day7 {
    public static void main(String[] args) {
        int [] arr = {4, 2, 2, 2, 4};
        int mid = arr.length/2;
        int fee = 2;
        int maxProfit1 = 0;
        int maxProfit2 = 0;
        int bestBuy1 = arr[0];
        int bestBuy2 = arr[mid+1];
        for (int i = 1; i <= mid ; i++) {
            if(arr[i] > bestBuy1){
                maxProfit1 = Math.max(maxProfit1,(arr[i] - bestBuy1));
            }
            bestBuy1 = Math.min(bestBuy1,arr[i]);
        }
        for (int i = mid + 2; i < arr.length ; i++) {
            if(arr[i] > bestBuy2){
                maxProfit2 = Math.max(maxProfit2,(arr[i] - bestBuy2));
            }
            bestBuy2 = Math.min(bestBuy2,arr[i]);
        }

        System.out.println(maxProfit1);
        System.out.println(maxProfit2);

        int maxProfit = maxProfit1 + maxProfit2;
        System.out.println(maxProfit);

        //Using Greedy Approach:-
        int Profit = 0;
        for(int i = 1; i < arr.length; i++){
            if(arr[i] > arr[i - 1]){
                Profit += arr[i] - arr[i - 1];
            }
        }
        System.out.println(Profit);

    }
}
