public class Product_Subarray_Day11 {
    public static void main(String[] args) {
        int [] arr = {-2, 6, -3, -10, 0, 2};
        int curr = 1;
        int maxProduct = Integer.MIN_VALUE;
        for(int i = 0; i < arr.length; i++) {
            curr *= arr[i];
            maxProduct = Math.max(maxProduct,curr);
            if(curr == 0){
                curr = 1;
            }
        }

        curr = 1;
        for (int i = arr.length - 1; i >= 0 ; i--) {
            curr *= arr[i];
            maxProduct = Math.max(maxProduct,curr);
            if(curr == 0){
                curr = 1;
            }
        }
        System.out.println(maxProduct);
    }
}
