package Graph;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Krushkals {
    public static class Edge{
        int src;
        int dest;
        int weight;

        public Edge(int src, int dest, int weight) {
            this.src = src;
            this.dest = dest;
            this.weight = weight;
        }
    }

    public static void createGraph(ArrayList<Edge>[] graph){
        for (int i = 0; i < graph.length; i++) {
            graph[i] = new ArrayList<>();
        }

        graph[0].add(new Edge(0, 1, 10));
        graph[0].add(new Edge(0, 2, 15));
        graph[0].add(new Edge(0, 3, 30));

        graph[1].add(new Edge(1, 0, 10));
        graph[1].add(new Edge(1, 3, 40));

        graph[2].add(new Edge(2, 0, 15));
        graph[2].add(new Edge(2, 3, 50));

        graph[3].add(new Edge(3, 1, 40));
        graph[3].add(new Edge(3, 2, 50));
    }

    static class DisjointSet{
        int[] parent;

        public DisjointSet(int n) {
            parent = new int[n];
            for (int i = 0; i < n; i++) {
                parent[i] = i;
            }
        }

        public int find(int x){
            if(parent[x] == x){
                return x;
            }

            return parent[x] = find(parent[x]);
        }

        public void union(int x, int y){
            int xRoot = find(x);
            int yRoot = find(y);
            if(xRoot != yRoot){
                parent[yRoot] = xRoot;
            }
        }
    }

    public static void krushkals(ArrayList<Edge>[] graph, int V){

        ArrayList<Edge> allEdges = new ArrayList<>();
        for (int i = 0; i < graph.length; i++) {
            for(Edge e : graph[i]){
                allEdges.add(e);
            }
        }


        Collections.sort(allEdges, Comparator.comparingInt(e -> e.weight));

        DisjointSet ds = new DisjointSet(V);
        int mstCost = 0;
        ArrayList<Edge> mstEdge = new ArrayList<>();

        for (Edge e : allEdges){
            int srcParent = ds.find(e.src);
            int destParent = ds.find(e.dest);

            if (srcParent != destParent){
                mstEdge.add(e);
                mstCost += e.weight;
                ds.union(srcParent,destParent);
            }
        }

        for (Edge e : mstEdge){
            System.out.println(e.src+ " "+ e.weight+" "+ e.dest);
        }
        System.out.println("Total cost: " +mstCost);
    }

    public static void main(String[] args) {
        int v = 6;
        ArrayList<Edge> [] graph = new ArrayList[v];
        createGraph(graph);
        krushkals(graph,v);
    }
}
