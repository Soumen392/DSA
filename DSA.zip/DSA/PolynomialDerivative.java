import java.util.Scanner;

public class PolynomialDerivative {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Step 1: Read the degree of the polynomial
        System.out.print("Enter the highest degree of the polynomial: ");
        int degree = scanner.nextInt();

        // Step 2: Initialize the polynomial array
        int[] poly = new int[degree + 1];

        // Step 3: Read coefficients for each term
        for (int i = degree; i >= 0; i--) {
            System.out.print("Enter coefficient for x^" + i + ": ");
            poly[i] = scanner.nextInt();
        }

        // Step 4: Take the derivative
        int[] derivative = new int[degree]; // Derivative will have one less degree
        for (int i = 1; i <= degree; i++) {
            derivative[i - 1] = poly[i] * i;
        }

        // Step 5: Print the result
        System.out.print("The derivative of the polynomial is: ");
        boolean isFirst = true;
        for (int i = degree - 1; i >= 0; i--) {
            if (derivative[i] != 0) {
                if (!isFirst && derivative[i] > 0) System.out.print(" + ");
                if (i == 0) System.out.print(derivative[i]);
                else if (i == 1) System.out.print(derivative[i] + "x");
                else System.out.print(derivative[i] + "x^" + i);
                isFirst = false;
            }
        }
    }
}
