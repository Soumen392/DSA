import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;

public class Customstack {
    int[] data;
    private static final int size = 10;

    int pointer = -1;

    public boolean push(int value){
        if(isFull()){
            System.out.println("The stack is full");
            return false;
        }
        pointer++;
        data[pointer] = value;
        return true;
    }

    public int pop() throws StackException{
        if(isEmpty()){
            throw new StackException("The Stack is empty");
        }
        return data[pointer--];
    }
    public void display(){
        for(int item : data){
            System.out.println(item);
        }
    }

    public int peek() throws StackException{
        if(isEmpty()){
            throw new StackException("The Stack is empty can't peek");
        }
        return (data[pointer]);
    }

    public boolean isEmpty(){
        return pointer == -1;
    }

     public boolean isFull() {
       return pointer == data.length - 1;
    }

    public Customstack() {
        this(size);
    }

    public Customstack(int size) {
        this.data = new int[size];
    }
}
