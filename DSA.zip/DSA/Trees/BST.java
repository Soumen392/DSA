public class BST {
    private static class Node{
        Node left;
        Node right;
        int value;
        int height;
        public Node(int value) {
            this.value = value;
        }

        public int getValue(){
            return value;
        }
    }
    private Node root;

    public int height(Node node){
        if(node == null){
            return -1;
        }
        return node.height;
    }

    public boolean isEmpty(){
        return root == null;
    }

    public void populate(int[] nums) {
        for (int i = 0; i < nums.length; i++) {
            this.insertValue(nums[i]);
        }
    }

    public void insertValue(int value){

        root = insertValue(root,value);

    }

    public void insertSortedValue(int[] arr){
        insertSortedValue(arr,0,arr.length);
    }

    private void insertSortedValue(int[] arr, int start, int end) {
        if(start >= end){
            return;
        }

        int mid = start + (end - start)/2;
        this.insertValue(arr[mid]);
        insertSortedValue(arr,start,mid);
        insertSortedValue(arr,mid+1,end);
    }

    private Node insertValue(Node node, int value){
        if(node == null){
            return node = new Node(value);
        }
        if(value < node.value){
            node.left = insertValue(node.left,value);
        }
        if(value > node.value){
            node.right = insertValue(node.right, value);
        }

        node.height = Math.max(height(node.left), height(node.right)) + 1;

        return node;
    }

    public boolean balanced(){
        return balanced(root);
    }

    private boolean balanced(Node node){
        if(node == null){
            return true;
        }

        return Math.abs(height(node.left) - height(node.right)) <= 1 && balanced(node.left) && balanced(node.right);
    }

    public void display(){
        display(root, "Root Node: ");
    }

    private void display(Node node, String info) {
        if(node == null){
            return;
        }
        System.out.println(info + node.value);
        display(node.left,"Left child of " + node.value + " : ");
        display(node.right,"Right child of " + node.value + " : ");

    }

}
