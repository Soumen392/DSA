package Trees;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//        Binarytree tree = new Binarytree();
//        tree.populate(scanner);
//        tree.prettyDisplay();

        int[] arr = {1,2,3,4,5,6,7,8,9};
//        BST tree = new BST();
//        tree.populate(arr);
//        tree.insertSortedValue(arr);
//        System.out.println(tree.balanced());
//        tree.display();


    }
}
