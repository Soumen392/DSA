import java.util.Scanner;

public class Problem_5_ii {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int s=sum(0,sc.nextInt(),1);
        System.out.println(s);
    }

    private static int sum(int ans,int n,int i) {
        if(n==0) {
            return ans;
        }
        if(n%2!=0)
        {
            if(i%2==0){
                return sum(ans-(int)Math.pow(n,2),n-1,i+1);
            }
            else {
                return sum(ans+(int)Math.pow(n,2),n-1,i+1);
            }
        }
        return sum(ans,n-1,i);
    }
}
