import java.util.Scanner;

public class Problem1 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter two nos.");
        int a = sc.nextInt();
        int b = sc.nextInt();

        int gcd = gcd(a, b);
        System.out.println("The GCD of " + a + " and " + b + " is: " + gcd);
    }

    // Recursive function to calculate GCD
    public static int gcd(int a, int b) {
        if (b == 0) {
            return a;
        }
        return gcd(b, a % b);  // Recursive case: GCD(b, a % b)
    }
}
