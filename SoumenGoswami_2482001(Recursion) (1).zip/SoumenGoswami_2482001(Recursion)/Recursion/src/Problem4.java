import java.util.Scanner;
//Write a recursive function to calculate the sum of all digits of a number entered by the user.
public class Problem4 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the digits");
        int n=sc.nextInt();
        int sum=calciSum(n,0);
        System.out.println(sum);
    }

    private static int calciSum(int n,int sum) {
        if(n==0)
            return sum;
       int rem=n%10;
       sum+=rem;
       n=n/10;
       return calciSum(n,sum);
    }
}
