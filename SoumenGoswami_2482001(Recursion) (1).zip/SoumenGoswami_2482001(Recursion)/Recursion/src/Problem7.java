import java.util.Arrays;

//Write a Program to reverse an array using a recursive function.
public class Problem7 {
    public static void main(String[] args) {
        int [] arr={1,2,3,4,5};
        int len= arr.length-1;
        int first=0;
       reverse(arr,first,len);
        System.out.println(Arrays.toString(arr));
    }

    private static void reverse(int[] arr,int first,int last) {
        if(first>=last){
            return;
        }
        int temp=arr[first];
        arr[first]=arr[last];
        arr[last]=temp;
        reverse(arr,first+1,last-1);
    }
}
