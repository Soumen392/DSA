import java.util.Arrays;
//6. Write a Program to implement Binary Search using a recursive function.
public class Problem6 {
    public static void main(String[] args) {
        int [] arr={2,4,6,8,1,10};
        int target=12;
        Arrays.sort(arr);
        binarySearch(arr,target,0,arr.length-1,0);
    }

    private static void binarySearch(int[] arr, int target, int start, int end,int i) {
       int mid=start+(end-start)/2;
        if (start>end){
            System.out.println("not found  ");
            return;
        }
        if(arr[mid]==target){
            System.out.println("found at ");
            return;
        }

        if(arr[mid]>target){
            binarySearch(arr,target,start,mid-1,i+1);
        }
        else {
            binarySearch(arr, target, mid+1, end, i + 1);
        }
    }
}
