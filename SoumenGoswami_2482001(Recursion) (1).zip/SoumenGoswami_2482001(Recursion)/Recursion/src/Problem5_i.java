import java.util.Scanner;

public class Problem5_i {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int s=sum(n,0);
        System.out.println(s);
    }

    private static int sum(int n,int sum) {
        if(n==2)
            return n+sum;
        return sum(n-2,sum+n);
    }
}
