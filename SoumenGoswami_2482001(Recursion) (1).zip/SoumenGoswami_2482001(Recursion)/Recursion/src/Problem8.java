import java.util.Scanner;

//Write a Program to calculate the length of the string using a recursive function.
public class Problem8 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the string");
        String s=sc.next();
        int len=0;
        int length=calculateLength(s,len,0);
        System.out.println(length);
    }

    private static int calculateLength(String s, int len, int i) {
        if(i==s.length()){
            return len;
        }

       return calculateLength(s,len+1,i+1);
    }
}
