import java.util.Scanner;
//2. Write a recursive function to print the first n Fibonacci numbers.
public class Problem2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of Fibonacci numbers to print:");
        int s = sc.nextInt();

        // Print Fibonacci numbers by calling the recursive function for each index
        for (int i = 0; i < s; i++) {
            System.out.print(fibo(i) + " ");
        }
    }

    // Recursive function to calculate the Fibonacci number at position 's'
    private static int fibo(int n) {
        return (int) ((1/Math.sqrt(5)) * ( Math.pow(((1 + Math.sqrt(5))/2),n) - Math.pow(((1 - Math.sqrt(5))/2),n)));
    }
}
