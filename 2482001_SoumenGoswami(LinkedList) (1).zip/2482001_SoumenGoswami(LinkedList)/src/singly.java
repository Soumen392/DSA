class node<T> {
    public node<T> next;
    public T data;

    public node(){}

    public node(T n)
    {
        this.data=n;
        this.next=null;
    }
}

class list<T>
{
    node<T> head;
    public list()
    {
        this.head=null;
    }

    void insert_at_any(int position, T data) {
        if (position < 1) {  // Position should be at least 1
            System.out.println("Invalid position");
            return;
        }

        node<T> nn = new node<>(data); // Create new node

        if (position == 1) {  // Insert at head
            nn.next = head;
            head = nn;
            return;
        }

        node<T> temp = head;
        int count = 1;

        // Traverse to the node just before the desired position
        while (temp != null && count < position - 1) {
            temp = temp.next;
            count++;
        }

        if (temp == null) {  // If position is beyond list size
            System.out.println("Position out of bounds");
            return;
        }

        // Insert the node
        nn.next = temp.next;
        temp.next = nn;
    }


    void del_at_any(int position)
    {
        int pos=position;
        int count=1;

        if(pos==1)
        {
            head=null;
        }
        if(head==null)
        {
            System.out.println("NO node is there to delete");
        }
        node<T> temp=head;
        while(temp!=null && count<=pos-1)
        {
            count++;
            temp=temp.next;
        }
        if(temp!=null)
        {
            temp.next=temp.next.next;
        }
    }

    void display()
    {
        node<T> temp=head;

        while(temp!=null)
        {
            System.out.println(temp.data);
            temp=temp.next;
        }
    }

    void LinearSearch(T x)
    {
        node<T> temp=head;
        int count=1;
        Boolean flag=false;
        while(temp!=null)
        {

            if(temp.data.equals(x))
            {

                System.out.println(temp.data+ " found at "+count);
                flag=true;
            }
            count++;
            temp=temp.next;
        }
        if(!flag)
        {
            System.out.println("not found"+x);
        }
    }
    void after_specified_ele(T ele,T data)
    {
        node<T> temp=head;
        node<T> nn=new node(data);
        int flag=0;
        if(head==null)
        {
            System.out.println("No node is created");
        }
        while(temp!=null )
        {
            if(temp.data.equals(ele))
            {
                flag=1;
                break;
            }
            temp=temp.next;
        }
        if(temp!=null)
        {
            nn.next=temp.next;
            temp.next=nn;
        }
    }

    void del_at_specified(T ele)
    {
        node<T> temp=head;
        node<T> prev=head;
        int flag=0;
        if(head==null)
        {
            System.out.println("nothing to delete ");
        }

        while(temp!=null)
        {
            if(temp.data.equals(ele))
            {
                flag=1;
                break;
            }
            temp=temp.next;
            prev=prev.next;
        }
        prev.next=temp.next;

    }

    void count_nodes()
    {
        node<T> temp=head;
        int count=0;
        if(head==null)
        {
            System.out.println("No node present");
        }
        while(temp!=null)
        {
            count++;
            temp=temp.next;
        }
        System.out.println(count+ " this is the number of nodes");
    }

    void reverse()
    {
        node<T> prev=null;
        node<T> next=null;
        node<T> curr=head;

        while(curr!=null)
        {
            next=curr.next;
            curr.next=prev;
            prev=curr;
            curr=next;

        }
        head=prev;

    }

    void concat(node<T> head1,node<T> head2)
    {
        if(head1==null)
        {
            head=head2;
        }

        node<T> temp=head1;
        while(temp.next!=null)
        {
            temp=temp.next;
        }
        temp.next=head2;
        head=head1;
    }
}

public class singly {
    public static void main(String[] args) {
        list<Integer> myList=new list<>();

        myList.insert_at_any(1, 10);
        myList.insert_at_any(2, 20);
        myList.insert_at_any(3, 30);
        myList.insert_at_any(2, 15);


        System.out.println("List after insertions:");
        myList.display();

        //searching an element
        myList.LinearSearch(10);

        //delete by specified element
        myList.del_at_specified(10);

        //count the no. of nodes
        myList.count_nodes();

        //reversing the list
        myList.reverse();
        myList.display();

        list<Integer> myList2 = new list<>();
        myList2.insert_at_any(1, 40);
        myList2.insert_at_any(2, 50);
        myList2.insert_at_any(3, 60);

        System.out.println("concatinating two lists");
        //concatinating two list
        myList2.concat(myList.head,myList2.head);
        myList.display();




    }
}