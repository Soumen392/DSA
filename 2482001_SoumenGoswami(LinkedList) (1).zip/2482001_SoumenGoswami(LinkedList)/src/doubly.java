class nodex<T>{
    public nodex<T> next = null;
    public nodex<T> prev = null;
    public T data;

    public nodex() {}

    public nodex(T data) {
        this.data = data;
    }
}

class DoublyList<T> {
    nodex<T> head;

    public DoublyList() {
        this.head = null;
    }

    void insert_at_any(int pos, T data) {
        nodex<T> newnode = new nodex<>(data);
        if (pos < 1) {
            System.out.println("Invalid position");
            return;
        }

        if (pos == 1) {  // Insert at head
            newnode.next = head;
            if (head != null) {
                head.prev = newnode;
            }
            head = newnode;
            return;
        }

        nodex<T> temp = head;
        int count = 1;

        while (temp != null && count < pos - 1) {
            temp = temp.next;
            count++;
        }

        if (temp == null) {
            System.out.println("Out of bound");
            return;
        }

        newnode.next = temp.next;
        newnode.prev = temp;

        if (temp.next != null) {
            temp.next.prev = newnode;
        }
        temp.next = newnode;
    }

    void del_at_any(int pos) {
        if (head == null || pos < 1) {
            System.out.println("No node is present or invalid position");
            return;
        }

        if (pos == 1) {  // Deleting head node
            head = head.next;
            if (head != null) {
                head.prev = null;
            }
            return;
        }

        nodex<T> temp = head;
        int count = 1;

        while (temp != null && count < pos) {
            temp = temp.next;
            count++;
        }

        if (temp == null || temp.prev == null) {
            System.out.println("Out of bound");
            return;
        }

        temp.prev.next = temp.next;
        if (temp.next != null) {
            temp.next.prev = temp.prev;
        }
    }

    void display() {
        nodex<T> temp = head;
        while (temp != null) {
            System.out.print(temp.data + " <--> ");
            temp = temp.next;
        }
        System.out.println("null");
    }
}

public class doubly {
    public static void main(String[] args) {
        DoublyList<Integer> list = new DoublyList<>();

        list.insert_at_any(1, 10);
        list.insert_at_any(2, 20);
        list.insert_at_any(3, 30);
        list.display();

        list.del_at_any(2);
        list.display();
    }
}
