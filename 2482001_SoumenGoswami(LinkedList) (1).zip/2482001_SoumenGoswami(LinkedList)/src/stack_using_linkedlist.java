import java.util.Scanner;

class Nodex<T>{
    public T data;
    public Nodex<T> next;

    Nodex(T data)
    {
        this.data=data;
        this.next=null;
    }
}

class stack_link<T>{
    Nodex<T> head;


    public void push(T data)
    {
        Nodex<T> head=null;
        Nodex<T> nn=new Nodex<>(data);
        if(head==null)
        {
            head=nn;
            head.next=null;
        }
        else{
            nn.next=head;
            head=nn;

        }
        System.out.println("Data is pushed...");
    }
    public void display()
    {
        Nodex<T> temp=head;
        while(temp!=null)
        {
            System.out.println(temp.data+"-->");
            temp=temp.next;
        }

    }
    public void pop()
    {
        if(head==null)
        {
            System.out.println("NO data is inserted");
        }
        else{
            System.out.println(head.data+" is popped");
            head=head.next;
        }

    }
}

public class stack_using_linkedlist {
    public static void main(String[] args) {

        stack_link<Integer> mystack=new stack_link<>();

        Scanner sc=new Scanner(System.in);

        while(true){
            System.out.println("1. push// 2. pop//3.display//4. exit");
            int ch=sc.nextInt();
            switch (ch) {
                case 1:
                    System.out.println("enter the number");
                    int input=sc.nextInt();
                    mystack.push(input);

                    break;

                case 2:
                    mystack.pop();
                    break;
                case 3:
                    mystack.display();
                    break;
                case 4:
                    System.exit(0);
                    break;

                default:
                    System.out.println("bhaag sala");
            }
        }
    }
}
