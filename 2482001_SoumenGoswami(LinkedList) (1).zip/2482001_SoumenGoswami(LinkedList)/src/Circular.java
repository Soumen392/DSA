class Node<T>{
    public Node<T> next;
    public Node<T>  prev;
    public T data;

    public Node(T data)
    {
        this.data=data;
        this.next=this.prev=null;
    }
}

class CircularList<T>
{

}


public class Circular {
    public static void main(String[] args) {

    }
}
